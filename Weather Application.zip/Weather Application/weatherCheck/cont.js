const butt = document.getElementById("button"); 

function fun() {
   butt.onclick = function() { 
      alert("Feedback Submitted");
   };
}fun(); 
